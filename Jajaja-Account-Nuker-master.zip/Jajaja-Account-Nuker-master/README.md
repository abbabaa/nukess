# Jajaja-Account-Nuker
Account nuker, discord token fucker for discord. (will revamp/fix soon.)

![](https://github.com/xanthe1337/Jajaja-Account-Nuker/blob/master/images/W4VcGw.png?raw=true)

# Installation and Use 
__Install Python3__
 
 -https://www.python.org/download/releases/3.0/

__Install chromedriver.exe__
 
 - https://chromedriver.chromium.org/downloads

__Clone The Rep__
  
  - Git clone https://github.com/azaelgg/Jajaja-Account-Nuker
  
  - cd Jajaja-Account-Nuker

__Run__
  - Python3 jajaja.py
  
# Legality

Everything you can see here has been made for educational purposes and proof of concepts. I do not promote the usage of my tools, I do not take responsability on the bad usage of this tool.
